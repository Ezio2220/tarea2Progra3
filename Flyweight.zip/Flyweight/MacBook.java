/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Flyweight;

/**
 *
 * @author franklinfuentes
 */
public  class MacBook {
    private String id;
    private int ram;
    private int disco;
    private static int conta;
    
    public MacBook getall(){
        return this;
    }
    public MacBook(String id1, int ram1, int disco1){
       super();
       this.id=id1;
       this.ram=ram1;
       this.disco=disco1;
       this.conta++;
       System.out.println(conta);
    }
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getRam() {
        return ram;
    }

    public void setRam(int ram) {
        this.ram = ram;
    }

    public int getDisco() {
        return disco;
    }

    public void setDisco(int disco) {
        this.disco = disco;
    }

    public int getConta() {
        return conta;
    }
    
    
    
}
