/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Flyweight;

import java.util.Scanner;

/**
 *
 * @author franklinfuentes CF17002
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      /* MacBook m1 = new MacBook("I1",4,128);
       MacBook m2 = new MacBook("I2",5,500);*/
      MacBookImpFlightWeight m1 = new MacBookImpFlightWeight("I1");
      boolean rep=true;int op=0;String code,aux; int ram,disco;
      Scanner sc = new Scanner(System.in);
      while(rep){
        System.out.println("menu:");
        System.out.println("1-agregar macbook");
        System.out.println("2-mostrar numero de macbooks");
        System.out.println("3-buscar una macbook");
        System.out.println("4-salir");
        do{
        op = sc.nextInt();
        }while(op<1||op>4);
        switch(op){
            case 1:{
                System.out.println("NO hay validaciones por favor ingrese correctamente los datos");
                System.out.println("Escriba el codigo:");
                code = sc.next();
                System.out.println("Escriba la cantidad de ram sin decimales");
                ram = sc.nextInt();
                System.out.println("Escriba la cantidad de Mb en disco sin decimales");
                disco = sc.nextInt();
                m1.Create(code, ram, disco);
                break;
            }
            case 2:{
                System.out.println("N° de macbooks registradas: "+m1.getconta());
                break;
            }
            case 3:{
                System.out.println("escriba el id del macbook a buscar");
                aux = sc.next();
                m1.Find(aux);
                System.out.println("MACBOK CODIGO: "+aux);
                System.out.println("RAM: "+m1.getRam());
                System.out.println("DISCO: "+m1.getDisco());
                
                break;
            }
            case 4:{
                rep =false;
                System.out.println("GRACIAS!");
                break;
            }
        }
      }
      /*for(int i=0;i<20;i++){
          m1.Create("a"+String.valueOf(i), 8+i, 500+i);
      }
        m1.Find("a10");
        System.out.println(m1.getRam()+" "+m1.getDisco());
      */
      
              
       
       
    }
    
}
