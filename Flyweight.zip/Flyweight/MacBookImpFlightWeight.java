/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Flyweight;
//w0p5ue CLAVE

import java.util.ArrayList;

/**
 *
 * @author franklinfuentes
 */
public class MacBookImpFlightWeight implements MacBook1 {
    private String id;
    private MacBook mac1ligero;
    private ArrayList<MacBook> list;
    
    public void Create(String id,int ram,int disco){
        
        this.mac1ligero = new MacBook(id,ram,disco);
        this.list.add(mac1ligero);
        
    }
    public void Find(String id){
        for(MacBook m: this.list){
            //System.out.println(id);
            if(id.equals(m.getId())){
                this.mac1ligero = m.getall();
            }
        }
    }
   
    public MacBookImpFlightWeight(String id){
        this.list = new <MacBook>ArrayList();
        this.id = id;                
        
    }
    @Override
    public String getID() {
        return this.id;
        
    }

    @Override
    public int getRam() {
        if(this.mac1ligero.getConta()>0){
        return this.mac1ligero.getRam();
        }else{
            return 0;
        }
    }

    @Override
    public int getDisco() {
        if(this.mac1ligero.getConta()>0){
        return this.mac1ligero.getDisco();
        }else{
            return 0;
        }
    }
    @Override
    public int getconta(){
        return this.mac1ligero.getConta();
    }
    
    
}
