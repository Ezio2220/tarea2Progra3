/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cajero;

/**
 *
 * @author franklinfuentes
 */
public class Ahorrante {
    private String nombre;
    private String contra;//contraseña
    private double saldo;
    
    public String getNombre(){
        return this.nombre;
    }
    public double getSaldo(){
        return this.saldo;
    }
    public void setNombre(String nm){
        this.nombre = nm;
    }
    public void setSaldo(double sal){
        this.saldo = sal;
    }
    public void setContra(String con){
        this.contra = con;
    }
    public String getContra(){
       return this.contra;
    }
    
}
