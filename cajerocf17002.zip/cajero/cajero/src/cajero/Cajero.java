/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cajero;
import java.io.*;
import java.util.*;
import java.awt.Toolkit;
/**
 *
 * @author franklinfuentes
 */
public class Cajero {
    static String  id="";
    static boolean rep=true,rep2 = true;
    static AhorranteDirector dir = new AhorranteDirector();
    static Ahorrante usuario;    
    
    /**
     * @param args the command line arguments
     */
   
    
    public static void main(String[] args) throws IOException {
        Date date ;Toolkit tk = Toolkit.getDefaultToolkit();
        String nombre,pass,comp1,comp2,code="",pas="",name="";
        double saldo=0.0;
        String ruta = "/home/franklinfuentes/NetBeansProjects/cajero/src/cajero/";
        Scanner sc = new Scanner(System.in);
    while(rep2){
        pas="";name="";
        rep=true;
        sc.reset();
        System.out.println("    _/_/_/    _/                                                      _/        _/           \n" +
                           "   _/    _/        _/_/    _/_/_/    _/      _/    _/_/    _/_/_/          _/_/_/    _/_/    \n" +
                           "  _/_/_/    _/  _/_/_/_/  _/    _/  _/      _/  _/_/_/_/  _/    _/  _/  _/    _/  _/    _/   \n" +
                           " _/    _/  _/  _/        _/    _/    _/  _/    _/        _/    _/  _/  _/    _/  _/    _/    \n" +
                           "_/_/_/    _/    _/_/_/  _/    _/      _/        _/_/_/  _/    _/  _/    _/_/_/    _/_/       ");
        
        boolean comp3=true;
        do{
            System.out.print("        +-----------------------------+\n" +
                               "        |Ingrese su Nombre de Usuario:|\n" +
                               "        +-----------------------------+\n"+
                               "        +-->");
                               
        nombre = sc.next();
        if(nombre.equals("<><>^vab")){//CODIGO PARA ENTRAR AL FORMULARIO DE CREACION  DE AHORRANTES
     
            tk.beep();tk.beep();
            System.out.println("        Konami activado!!!");
            cuentas cs = new cuentas();
            cs.setVisible(true);
        }
            //System.out.println(nombre);
            System.out.print("        +----------------------+\n" +
                               "        |Ingrese su contraseña:|\n" +
                               "        +----------------------+\n"+
                               "        +-->");
        pass = sc.next();
        comp1=TXT.buscarArchivocf(ruta+"usuarios.txt", nombre);
        comp2=TXT.buscarArchivocf(ruta+"usuarios.txt", pass);
            //System.out.println(comp1);
        for(int i=0;i<comp2.length();i++){
            if(comp2.charAt(i)==':'){
                for(int j=i+1;j<comp2.length();j++){
                    pas+=comp2.charAt(j);
                }
                i=comp2.length();
            }
        }
        for(int i=0;i<comp1.length();i++){
            if(comp1.charAt(i)=='-'){
                for(int j=i+1;j<comp1.length();j++){
                    name += comp1.charAt(j);
                    if(comp1.charAt(j+1)==' '){
                        j=comp1.length();
                        i=j;
                    }
                }
            }
        }
            
        if(comp1.length()==comp1.length() && nombre.equals(name) && pass.equals(pas) ){
            
            comp3=false;
        }else{
            comp3=true;
        }
        if(comp3){
            System.out.println("        +-----------------------------------+\n" +
                               "        |usuario y/o contraseña incorrectos!|\n" +
                               "        +-----------------------------------+");
        }else{
            for(int i=0;i<comp1.length();i++){
                if(comp1.charAt(i)=='-'){
                    i=comp1.length();
                }else{
                    code+=comp1.charAt(i);
                }
                
            }
            //System.out.println(code);
            id=code;
        }
        }while(comp3);
        comp1 = TXT.buscarArchivocf(ruta+"saldo.txt", id+"- ");
        for(int i=0;i<comp1.length();i++){
            if(comp1.charAt(i)=='$'){
                comp2="";
                for(int j=i+1;j<comp1.length();j++){
                    comp2+=comp1.charAt(j);
                    
                }
                i=comp1.length();
                //System.out.println(saldo);
                saldo = Double.parseDouble(comp2);
            }
        }
        dir.setAhorranteBuilder(new userBuilder());
        dir.constructAhorrante(nombre, pass, saldo);
        usuario = dir.getAhorrante();
        int op;
        while(rep){
            System.out.print(  "             +--------+\n" +
                               "             |  MENU  |\n" +
                               "        +----v--------v----+\n" +
                               "        |  1-Retirar       |\n" +
                               "        |  2-Abonar        |\n" +
                               "        |  3-Mostrar Saldo |\n" +
                               "        |  4-Salir         |\n" +
                               "        +------------------+\n" +
                               "        |\n" +
                               "        +-->");
        do{
        op = sc.nextInt();
        if(op<1 || op>4){
            System.out.print("        +-----------------+\n" +
                               "        |Opcion no Valida!|\n" +
                               "        +-----------------+\n" +
                               "        +--->");
        }
        }while(op<1 || op>4);
        
        switch(op){
            case 1:{
                date=new Date();
                dir.Retirar(usuario);
                dir.getTransaccion();
                usuario = dir.getAhorrante();
                TXT.modificarlineaArchivoin(ruta+"saldo.txt", id+'-', "$"+String.valueOf(usuario.getSaldo()));
                TXT.AgregarArchivofr(ruta+"transacciones.txt", id+"- Retiro $"+String.valueOf(saldo-usuario.getSaldo())+":"+date.getDate()+"/"+date.getMonth()+"/"+(date.getYear()+1900)+"*");
                saldo = usuario.getSaldo();
                
                break;
            }
            case 2:{
                date = new Date();
                dir.Abonar(usuario);
                dir.getTransaccion();
                usuario = dir.getAhorrante();
                TXT.modificarlineaArchivoin(ruta+"saldo.txt", id+'-', "$"+String.valueOf(usuario.getSaldo()));
                TXT.AgregarArchivofr(ruta+"transacciones.txt", id+"- Abono $"+String.valueOf(usuario.getSaldo()-saldo)+":"+date.getDate()+"/"+date.getMonth()+"/"+(date.getYear()+1900)+"*");
                saldo = usuario.getSaldo();
                break;
            }
            case 3:{
                System.out.println("        +--------------------------->\n" +
                                   "        |USUARIO:"+usuario.getNombre()+"\n" +
                                   "        |Saldo Actual: $"+String.valueOf(saldo)+"\n" +
                                   "        +--------------------------->");
                break;
            }
            case 4:{
                int res;
                System.out.print(  "             +-------+\n" +
                                   "             |Opcion:|\n" +
                                   "        +----v-------v---+\n" +
                                   "        |>1-Cerrar Sesion|\n" +
                                   "        |>2-Cerrar Todo  |\n" +
                                   "        +----------------+\n"+"        >");
                res = sc.nextInt();
                if(res==1){
                    rep = false;
                    rep2=true;
                    code="";
                    saldo=0.00;
                    
                    
                }else{
                    rep=false;
                    rep2=false;
                    code="";
                    saldo=0.00;
                }
                System.out.println("");
            }
        }
                
        }
        //sc.close();
    }
    
        System.out.println("  _|_|_|  _|_|_|      _|_|      _|_|_|  _|_|_|    _|_|      _|_|_|  \n" +
                           "_|        _|    _|  _|    _|  _|          _|    _|    _|  _|        \n" +
                           "_|  _|_|  _|_|_|    _|_|_|_|  _|          _|    _|_|_|_|    _|_|    \n" +
                           "_|    _|  _|    _|  _|    _|  _|          _|    _|    _|        _|  \n" +
                           "  _|_|_|  _|    _|  _|    _|    _|_|_|  _|_|_|  _|    _|  _|_|_|   ");
        System.exit(0);
    }
    
}
