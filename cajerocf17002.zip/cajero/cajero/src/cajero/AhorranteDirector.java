/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cajero;

/**
 *
 * @author franklinfuentes
 */
public class AhorranteDirector {
    private AhorranteBuilder builder;
    private Transaccion acciones = new Transaccion();
    
    public void constructAhorrante(String nombre,String contra,double saldo){
        builder.crearAhorrante();
        builder.buildNombre(nombre);
        builder.buildContra(contra);
        builder.buildSaldo(saldo);
        acciones.setTipo("NULL");
    }
    public void setAhorranteBuilder(AhorranteBuilder ab){
        this.builder = ab;
        
    }
    public void Retirar(Ahorrante ab){
        RetiroBuilder reb = new RetiroBuilder();
        reb.CrearRetiro(ab);
        reb.Retirar();
        this.acciones = reb.getTransaccion();
    }
    public void Abonar(Ahorrante ab){
        AbonoBuilder abb = new AbonoBuilder();
        abb.CrearAbono(ab);
        abb.Abonar();
        this.acciones = abb.getTransaccion();
    }
    public void getTransaccion(){
        switch(this.acciones.getTipo()){
            case "Retirar":{
                this.builder.getAhorrante().setSaldo(this.builder.getAhorrante().getSaldo()-this.acciones.getMonto()); 
                break;
            }
            case "Abonar":{
                this.builder.getAhorrante().setSaldo(this.builder.getAhorrante().getSaldo()+this.acciones.getMonto()); 
                break;
            }
            default :{
                break;
            }            
        }
        this.acciones.setTipo("NULL");
        System.out.println("        +--------------------+\n" +
                           "        |Transaccion Exitosa!|\n" +
                           "        +--------------------+");
    } 
    
    public Ahorrante getAhorrante(){
       return this.builder.getAhorrante();
    }
    
}
