/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cajero;
import java.util.Scanner;
/**
 *
 * @author franklinfuentes
 */
public class AbonoBuilder {
    private Ahorrante usuario;
    private Transaccion tran = new Transaccion();
    
    public void CrearAbono(Ahorrante ah){
        this.tran.setUser(ah);
        this.tran.setTipo("Abonar");
        this.usuario = ah;
    }
    public void Abonar(){
        Scanner sc = new Scanner(System.in);
        double monto=0.0;
        do{
            System.out.print("        +--------------------------+\n" +
                             "        | Digite el monto a Abonar:|\n" +
                             "        +--------------------------+\n" +
                             "        |\n" +
                             "        +-->");
            monto = sc.nextDouble();
            if(monto<1){
                System.out.println("        +------------------------+\n" +
                                   "        |La Cantidad no es valida|\n" +
                                   "        +------------------------+");
            }
        }while(monto<1);
        this.tran.setMonto(monto);
    }
    public Transaccion getTransaccion(){
        return this.tran;
    }
    
}
