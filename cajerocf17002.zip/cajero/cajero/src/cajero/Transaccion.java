/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cajero;

/**
 *
 * @author franklinfuentes
 */
public class Transaccion {
    private String Tipo ;
    private double monto;
    private Ahorrante user;
    
    public void transaccion(){
        monto = 0;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public Ahorrante getUser() {
        return user;
    }

    public void setUser(Ahorrante user) {
        this.user = user;
    }
    
    
}
