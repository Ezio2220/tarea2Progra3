/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cajero;
import java.util.Scanner;
/**
 *
 * @author franklinfuentes
 */
public class RetiroBuilder {
    private Ahorrante usuario;
    private Transaccion tran = new Transaccion();
    public void CrearRetiro(Ahorrante ah){
        this.tran.setUser(ah);
        this.tran.setTipo("Retirar");
        this.usuario = ah;
    }
    public void Retirar(){
        Scanner sc = new Scanner(System.in);
        double monto=0;
        
        do{ 
            System.out.print("        +------------------------------------------------------>\n" +
                             "        |Monto Disponible: $"+String.valueOf(usuario.getSaldo())+"Digite el monto a Retirar:\n" +
                             "        +------------------------------------------------------>\n" +
                             "        |\n" +
                             "        +-->");
            monto = sc.nextDouble();
        }while(monto>usuario.getSaldo() || monto < 0.01);
        this.tran.setMonto(monto);
        
    }
    public Transaccion getTransaccion(){
        return this.tran;
    }
   
    
}
