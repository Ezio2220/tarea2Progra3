/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cajero;

/**
 *
 * @author franklinfuentes
 */
public abstract class AhorranteBuilder {
    protected Ahorrante usuario ;
    
    public Ahorrante getAhorrante(){
        return this.usuario;
    }
    public void crearAhorrante(){
        usuario = new Ahorrante();
    }
    public abstract void buildNombre(String nombre);
    public abstract void buildContra(String contra);
    public abstract void buildSaldo(double saldo);
    
}
