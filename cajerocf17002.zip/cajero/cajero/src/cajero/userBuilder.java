/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cajero;
import java.util.Scanner;

/**
 *
 * @author franklinfuentes
 */
public class userBuilder extends AhorranteBuilder {

    @Override
    public void buildNombre(String nombre) {
      /*  System.out.println("ESCRIBA EL NOMBRE: ");
        Scanner sc = new Scanner(System.in);
        usuario.setNombre(sc.nextLine());*/
        //sc.close();
        usuario.setNombre(nombre);
    }

    @Override
    public void buildContra(String contra) {
        
        //Scanner sc = new Scanner(System.in);
        //String contra ="";
        /*do{
        System.out.println("ESCRIBA LA Contraseña: ");
         contra = sc.next(); 
        }while(contra==usuario.getNombre() || contra == usuario.getNombre().substring(0, 1));
        */
        usuario.setContra(contra);
        //sc.close();
    }

    @Override
    public void buildSaldo(double saldo) {
        /*System.out.println("ESCRIBA EL Saldo Inicial: ");
        Scanner sc = new Scanner(System.in);
        usuario.setSaldo(sc.nextDouble());*/
        //sc.close();
        usuario.setSaldo(saldo);
    }
    
    
}
