/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package actividad;

/**
 *
 * @author franklinfuentes
 */
public class aux {
    
    public static boolean comparaNumero(String comp){
        int tam;boolean tot=false;
        tam = comp.length();
        for(int i=0;i<tam;i++){
            if(comp.charAt(i)>='0'&&comp.charAt(i)<='9'){
                tot=false;
            }else{
                tot=true;
            }
        }
        return tot;
    }
    
}
