/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package actividad;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.*;
/**
 *
 * @author franklinfuentes cf17002
 */
public class minisystem {
     //SISTEMA de actividad crear arboles con : "nombre comun, familia , tipo, suelo y zona" menu: crar arboles, mostrar coleccion de arboles por familia y salir
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Arbol acum ;
        ArrayList<Arbol> lista = new <Arbol>ArrayList();
        String Comp;
        int op;
        boolean rep=true;
    while(rep){
        do{
        do{
        Comp=JOptionPane.showInputDialog("        MENU:\n    1-Agregar Arbol\n    2-Mostrar Catalogo de Arboles\n    3-Salir");
        }while(aux.comparaNumero(Comp));
        op=Integer.parseInt(Comp);
        }while(op<1||op>3);
        switch(op){
            case 1:{
                acum = new Arbol();
                acum.setNombre_comun(JOptionPane.showInputDialog("Escriba el nombre comun del arbol"));
                acum.setFamilia(JOptionPane.showInputDialog("Escriba la familia del arbol"));
                acum.setTipo(JOptionPane.showInputDialog("Escriba el tipo del arbol"));
                acum.setSuelo(JOptionPane.showInputDialog("Escriba el tipo de suelo del arbol"));
                acum.setZona(JOptionPane.showInputDialog("Escriba la zona del arbol"));
                lista.add(acum);
                break;
            }
            case 2:{
                
                Collections.sort(lista, (Arbol o1, Arbol o2) -> {
                    return new String (o1.getFamilia()).compareTo(new String(o2.getFamilia()));
                });
                
                String juntar="lol",cadena,cadena2="lol";
                cadena="";
                int iter=0;
                if(lista.size()==1){
                    Arbol iterador = lista.get(0);
                    cadena2=iterador.getFamilia();
                    cadena="nombre comun:"+iterador.getNombre_comun()+"\n"+"tipo de suelo:"+iterador.getSuelo()+"\n"
                    +"tipo de arbol:"+iterador.getTipo()+"\n"+"Zona:"+iterador.getZona()+"\n";
                    JOptionPane.showMessageDialog(null, cadena, "FAMILIA: "+cadena2, 0);
                }else{
                    for(Arbol iterador:lista){
                        iter++;
                        if(iter==1){
                        
                        }else if(!cadena2.equals(iterador.getFamilia())){
                           // System.out.println("cambio"+iterador.getNombre_comun());
                            JOptionPane.showMessageDialog(null, cadena, "FAMILIA: "+cadena2, 0);
                            cadena="";
                            if(iter==lista.size()){
                                //System.out.println("last"+iterador.getNombre_comun());
                                cadena2=iterador.getFamilia();
                                cadena="nombre comun:"+iterador.getNombre_comun()+"\n"+"tipo de suelo:"+iterador.getSuelo()+"\n"
                                +"tipo de arbol:"+iterador.getTipo()+"\n"+"Zona:"+iterador.getZona()+"\n";
                                JOptionPane.showMessageDialog(null, cadena, "FAMILIA: "+cadena2, 0);
                            }
                            
                        }else if(iter==lista.size()){
                              //  System.out.println("last"+iterador.getNombre_comun());
                                cadena2=iterador.getFamilia();
                                cadena+="nombre comun:"+iterador.getNombre_comun()+"\n"+"tipo de suelo:"+iterador.getSuelo()+"\n"
                                +"tipo de arbol:"+iterador.getTipo()+"\n"+"Zona:"+iterador.getZona()+"\n";
                                JOptionPane.showMessageDialog(null, cadena, "FAMILIA: "+cadena2, 0);
                            }
                            //System.out.println("add"+iterador.getNombre_comun());
                            cadena2=iterador.getFamilia();
                            cadena+="nombre comun:"+iterador.getNombre_comun()+"\n"+"tipo de suelo:"+iterador.getSuelo()+"\n"
                            +"tipo de arbol:"+iterador.getTipo()+"\n"+"Zona:"+iterador.getZona()+"\n";
                        
                        
                        
                    }
                }
                
                
                break;
            }
            case 3:{
                JOptionPane.showMessageDialog(null,"ADIOS!");
                rep=false;
             
                break;
            }
        }
    }
    }
    
}
